# TWD Turkish Translator (Android prototype)

This is a starter Android Studio project for a screen-OCR translation overlay.
It is source code, not a prebuilt or tested APK.

## What it does
- Requests Android's screen-capture consent (MediaProjection).
- Captures a screenshot when you tap the floating `Translate` button.
- Uses ML Kit Latin text recognition to read visible English subtitles.
- Sends recognized text to MyMemory's public translation endpoint (internet required).
- Shows the Turkish result in a floating overlay.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to sync.
3. Build > Build APK(s).
4. Install the debug APK on your phone.
5. Grant screen-capture permission and "Display over other apps".

## Important limitations
- This prototype translates on-demand, not continuously.
- Screen capture may be blocked by some apps or protected screens.
- Translation is sent to a third-party service; do not use it with private information.
- This project has not been compiled or tested here. Android Studio may request Gradle/plugin updates.
