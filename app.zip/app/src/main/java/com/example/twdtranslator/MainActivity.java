package com.example.twdtranslator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 41;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private WindowManager wm;
    private ViewOverlay overlay;
    private int screenWidth, screenHeight, density;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        TextView title = new TextView(this);
        title.setText("TWD Turkish Translator\\n\\n1. Allow overlay permission.\\n2. Start screen capture.\\n3. Open the game and tap Translate.");
        title.setTextSize(18);
        root.addView(title);
        Button permission = new Button(this);
        permission.setText("Allow display over other apps");
        root.addView(permission);
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this, "Overlay permission already allowed", Toast.LENGTH_SHORT).show();
        });
        Button start = new Button(this);
        start.setText("Start screen capture");
        root.addView(start);
        start.setOnClickListener(v -> startCapture());
        setContentView(root);
    }

    private void startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "First allow display over other apps", Toast.LENGTH_LONG).show();
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQUEST_CAPTURE && res == RESULT_OK && data != null) {
            MediaProjectionManager m = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = m.getMediaProjection(res, data);
            screenWidth = getResources().getDisplayMetrics().widthPixels;
            screenHeight = getResources().getDisplayMetrics().heightPixels;
            density = getResources().getDisplayMetrics().densityDpi;
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = projection.createVirtualDisplay("TWDTranslator", screenWidth, screenHeight,
                density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, handler);
            showOverlay();
        }
    }

    private void showOverlay() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(18, 12, 18, 12);
        panel.setBackgroundColor(0xEE20242A);
        TextView result = new TextView(this);
        result.setTextColor(0xFFFFFFFF);
        result.setTextSize(15);
        result.setText("TWD Translator hazır. Altyazı görünəndə Translate bas.");
        panel.addView(result);
        Button translate = new Button(this);
        translate.setText("Translate");
        panel.addView(translate);
        Button close = new Button(this);
        close.setText("Close");
        panel.addView(close);
        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        wm.addView(panel, p);
        overlay = new ViewOverlay(panel, result);
        translate.setOnClickListener(v -> captureAndTranslate());
        close.setOnClickListener(v -> {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            if (virtualDisplay != null) virtualDisplay.release();
            if (projection != null) projection.stop();
        });
    }

    private void captureAndTranslate() {
        if (imageReader == null) return;
        Image image = imageReader.acquireLatestImage();
        if (image == null) {
            overlay.text.setText("Ekran görüntüsü hazır deyil. Bir neçə saniyə sonra yenidən bas.");
            return;
        }
        int width = image.getWidth(), height = image.getHeight();
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride(), rowStride = plane.getRowStride();
        Bitmap full = Bitmap.createBitmap(rowStride / pixelStride, height, Bitmap.Config.ARGB_8888);
        full.copyPixelsFromBuffer(buffer);
        Bitmap cropped = Bitmap.createBitmap(full, 0, 0, Math.min(width, full.getWidth()), height);
        image.close();
        overlay.text.setText("Altyazı oxunur...");
        InputImage input = InputImage.fromBitmap(cropped, 0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(input)
            .addOnSuccessListener(text -> {
                String english = text.getText().trim();
                if (english.isEmpty()) { overlay.text.setText("Mətn tapılmadı. Altyazı görünəndə yenidən bas."); return; }
                translateText(english);
            })
            .addOnFailureListener(e -> overlay.text.setText("OCR xətası: " + e.getMessage()));
    }

    private void translateText(String source) {
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                String q = URLEncoder.encode(source, "UTF-8");
                URL url = new URL("https://api.mymemory.translated.net/get?q=" + q + "&langpair=en|tr");
                c = (HttpURLConnection)url.openConnection();
                c.setConnectTimeout(10000); c.setReadTimeout(10000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder s = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) s.append(line);
                r.close();
                String translated = new JSONObject(s.toString()).getJSONObject("responseData").getString("translatedText");
                handler.post(() -> overlay.text.setText(translated));
            } catch (Exception e) {
                handler.post(() -> overlay.text.setText("Tərcümə xətası. İnterneti yoxla və yenidən sına."));
            } finally { if (c != null) c.disconnect(); }
        });
    }

    private static class ViewOverlay {
        final LinearLayout panel; final TextView text;
        ViewOverlay(LinearLayout p, TextView t) { panel=p; text=t; }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        if (virtualDisplay != null) virtualDisplay.release();
        if (projection != null) projection.stop();
    }
}
